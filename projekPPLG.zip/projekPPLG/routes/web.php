<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\DokumenController;

Route::get('/', function () {
    route::resource('kategoris', KategoriController::class);
});
