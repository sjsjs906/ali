<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Kategori;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;

class KategoriController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $kategoris = Kategori::withCount('dokumens')->latest()->paginate(10);
 return view('kategori.index',compact('kategoris'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('kategori.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
      $request->validate([
 'nama_kategori' => 'required|string|max:100|unique:kategoris,nama_kategori',
 'deskripsi' => 'nullable|string',
 ]);
 Kategori::create($request->only(['nama_kategori', 'deskripsi']));
 return redirect()->route('kategori.index')
 ->with('success', 'Kategori berhasil ditambahkan.');


    }

    /**
     * Display the specified resource.
     */
    public function show(kategori $kategori)
    {
       return view('kategori.index',compact('kategori'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $kategori = kategori::findorfail($id);
        return view('kategori.edit',compact('kategori'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
         $kategori = kategori::findorfail($id);
        $request->validate([
            'nama_kategori' => 'required|string|max:100|unique:kategoris,nama_kategori,'. $kategori->$id,'deskripsi'=>'nullable|string',

        ]);
        $kategori->update($request->only(['nama_kategori','deskripsi']));

        return redirect()->route('kategori.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $kategori = Kategori::findOrFail($id);
        try{
            $kategori->delete();
        } catch(QueryException $e){
            return redirect()->route('kategori.index')->with('error','kategori'"'.$kategori->nama_kategori.'");
 return redirect()->route('kategori.index')
 ->with('success', 'Kategori berhasil di hapus.');
    }
}
