<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Dokumen extends Model
{
    protected $fillable = [
        'kategori_id',
        'user_id',
        'nomor_arsip',
        'judul_dokumen',
        'deskripsi',
        'nama_file',
        'tipe_file',
        'ukuran_file',
        'tanggal_arsip',
    ];
    protected $casts = [
        'tanggal_arsip' => 'date'
    ];
    public function kategori():BelongsTo
    {
        return $this->belongsTo(kategori::class);
    }
    public function user():BelongsTo
    {
        return $this->belongsTo(user::class);
    }
}
